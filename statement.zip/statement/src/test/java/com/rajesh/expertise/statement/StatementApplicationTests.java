package com.rajesh.expertise.statement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StatementApplicationTests {

	@Test
	void contextLoads() {
	}

}
